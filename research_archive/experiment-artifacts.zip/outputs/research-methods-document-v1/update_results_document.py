from pathlib import Path
from copy import deepcopy

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "財務問答標註實驗設計與欄位說明.docx"
OUTPUT = ROOT / "財務問答標註實驗設計與初步結果說明.docx"


def set_cell_format(cell, header=False):
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    props = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right"):
        edge = OxmlElement(f"w:{side}")
        edge.set(qn("w:val"), "single")
        edge.set(qn("w:sz"), "4")
        edge.set(qn("w:color"), "D9D9D9")
        borders.append(edge)
    props.append(borders)
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), "DCE6F1" if header else "FFFFFF")
    props.append(shading)
    margins = OxmlElement("w:tcMar")
    for side in ("top", "bottom", "left", "right"):
        margin = OxmlElement(f"w:{side}")
        margin.set(qn("w:w"), "38")
        margin.set(qn("w:type"), "dxa")
        margins.append(margin)
    props.append(margins)
    for paragraph in cell.paragraphs:
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 0.92
        for run in paragraph.runs:
            run.font.size = Pt(8.6)
            run.bold = header


def add_result_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    table.autofit = False
    for index, (cell, value, width) in enumerate(zip(table.rows[0].cells, headers, widths)):
        cell.text = value
        cell.width = Inches(width)
        set_cell_format(cell, header=True)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for values in rows:
        row = table.add_row()
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for cell, value, width in zip(row.cells, values, widths):
            cell.text = value
            cell.width = Inches(width)
            set_cell_format(cell)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def page_heading(doc, text):
    paragraph = doc.add_heading(text, level=1)
    paragraph.paragraph_format.page_break_before = True


doc = Document(SOURCE)

for paragraph in doc.paragraphs:
    if paragraph.text.startswith("本版不收錄實驗結果"):
        paragraph.text = (
            "本版納入固定版本前的 12 題 Development Set 小規模實測，"
            "用來說明 A、B、C、D 四組條件及 C、D 的實際差異。"
            "目前執行中的 60 題完整回歸結果尚未納入；小規模結果不得取代正式回歸結論。"
        )
    if paragraph.text.startswith("整理日期："):
        paragraph.text = (
            "整理日期：2026 年 9 月 17 日。方法部分對應 Protocol v1.1；"
            "初步結果取自 outputs/dev-prompt-v4/full-dev-v4/final-report，"
            "Judge 診斷取自 outputs/dev-judge-diagnostic-v1。"
        )

page_heading(doc, "十四　小規模實測結果")
doc.add_paragraph(
    "本節呈現正式 60 題回歸前已完成的小規模測試。首先要釐清：A、B、C、D 是四個實驗條件，"
    "不是四個模型。四組的 Generator 均為 gemma4:12b；另以 qwen3.5:9b 進行補充 Judge 診斷。"
    "因此，四組表格比較的是 Harness 元件逐步增加後的差異，不能解讀成模型能力排名。"
)
doc.add_heading("十二題 Development Set 的四組比較", level=2)
doc.add_paragraph(
    "測試規模為 12 題 × 4 組 × 3 次，共 144 個 question-runs。三次 run 的主要比率完全一致，"
    "所以表格列平均值；sample SD 為 0 只描述這三次觀察，不代表換題或換環境後仍無變異。"
    "語意標籤採 AI-assisted review，human_review_completed=false。"
)
add_result_table(
    doc,
    ("條件", "E2E", "首輪", "終止輪", "Recovery", "答案", "Evidence F1", "Python\n執行／一致"),
    (
        ("A", "16.7%", "16.7%", "16.7%", "0.0%", "58.3%", "91.7%", "83.3%／50.0%"),
        ("B", "33.3%", "33.3%", "33.3%", "0.0%", "50.0%", "91.7%", "83.3%／41.7%"),
        ("C", "100.0%", "33.3%", "100.0%", "100.0%", "100.0%", "100.0%", "100.0%／100.0%"),
        ("D", "100.0%", "33.3%", "100.0%", "100.0%", "100.0%", "100.0%", "100.0%／100.0%"),
    ),
    (0.55, 0.7, 0.7, 0.75, 0.85, 0.7, 0.9, 1.25),
)
doc.add_paragraph(
    "這組結果顯示，C、D 的改善主要發生在重試之後：兩組首輪 E2E 都是 33.3%，終止輪都達到 100.0%，"
    "而 A、B 沒有 Validator feedback retry。這支持『確定性回饋能修復目前 Dev 錯誤』，"
    "但不支持『D 的 Semantic Judge 比 C 額外提高準確率』，因為 C、D 的終止輪指標完全相同。"
)
doc.add_heading("C 與 D 的實測差異", level=2)
add_result_table(
    doc,
    ("觀察項目", "C 確定性驗證", "D 完整 Harness", "差異解讀"),
    (
        ("終止輪 E2E", "100.0%", "100.0%", "Judge 未增加本組最終正確題數"),
        ("首輪 E2E", "33.3%", "33.3%", "兩組起點相同"),
        ("Recovery", "100.0%", "100.0%", "錯題均在共同重試機制中恢復"),
        ("每題平均時間", "30.40 秒", "34.73 秒", "D 約增加 4.33 秒，約 14.2%"),
        ("總 attempts", "63", "66", "D 多 3 個 attempts"),
        ("終止於 attempt 1／2／3", "12／21／3", "12／18／6", "D 有較多題走到第三輪"),
        ("Judge requests", "0", "36", "只有 D 執行 fresh-context Judge"),
        ("Judge rejection", "不適用", "0", "自然 Dev 終止產物未被 Judge 拒絕"),
        ("終止狀態", "VALIDATED", "ACCEPTED", "狀態不同不等於準確率不同"),
    ),
    (1.15, 1.15, 1.2, 3.05),
)
doc.add_paragraph(
    "D 的主要可觀察代價是額外 Judge 呼叫與延遲，而不是本批題目的準確率增益。"
    "這不代表 Judge 永遠無效；它代表在這 12 題與現行 Generator 產物中，"
    "確定性驗證器已經把可恢復錯誤處理完，Judge 沒有遇到能改變終止答案的自然語意錯誤。"
)

page_heading(doc, "十五　Semantic Judge 診斷結果")
doc.add_paragraph(
    "為了確認 D 組新增的 Judge 是否具備攔截能力，另做合成錯誤診斷。這不是 A、B、C、D 的準確率測試，"
    "也不是正式 Test Set；它把正確標註與人工注入的錯誤交給兩個 Judge 模型，觀察接受與偵測行為。"
)
add_result_table(
    doc,
    ("Judge 模型", "案例", "可判定錯誤偵測", "正確案例接受", "錯誤拒絕", "平均延遲"),
    (
        ("gemma4:12b", "24", "9／9　100.0%", "12／12　100.0%", "0／12　0.0%", "4.991 秒"),
        ("qwen3.5:9b", "24", "8／9　88.9%", "12／12　100.0%", "0／12　0.0%", "2.507 秒"),
    ),
    (1.25, 0.65, 1.45, 1.4, 1.05, 1.05),
)
doc.add_paragraph(
    "每個模型的 24 案例包含 12 個 control、9 個可判定的 wrong concept／wrong constraint／wrong evidence，"
    "以及 3 個 missing context。Missing context 因缺乏必要資訊而被標為 blocked，不放入 9 題偵測率分母。"
    "Gemma 在合成錯誤上全部偵測，Qwen 漏掉 1 個 wrong constraint；兩者均接受所有 control，未發生 false rejection。"
)
doc.add_paragraph(
    "這項診斷說明 Judge 在刻意植入錯誤時有辨識能力，但不能直接證明它能提高自然題目的 Final Accuracy。"
    "合成錯誤較明確，樣本量也小；正式研究仍應以 C 對 D 的逐題轉移矩陣，"
    "統計 C 錯 D 對、C 對 D 錯、Judge false acceptance 與 false rejection。"
)
doc.add_heading("目前可以支持的結論", level=2)
doc.add_paragraph(
    "小規模結果支持確定性 Validator 與 feedback retry 對本批 Dev 題目有效；"
    "D 的 Judge 在合成診斷中能辨識語意錯誤，但在自然 Dev 實測中沒有比 C 增加終止輪正確率，"
    "並增加約 14.2% 的平均每題時間。這是目前可被資料支持的邊界，不能延伸為 D 無效或 D 必然優於 C。"
)
doc.add_heading("結果來源與適用限制", level=2)
doc.add_paragraph(
    "四組比較來源：outputs/dev-prompt-v4/full-dev-v4/final-report/summary.json。"
    "Judge 診斷來源：outputs/dev-judge-diagnostic-v1/summary.json。"
    "兩者皆為 Development 階段產物，並含 AI-assisted 判定；完整 60 題 Protocol v1.1 結果完成後應另章取代初步推論，"
    "不得把這裡的 100.0% 描述為正式 Test 表現。"
)

for section in doc.sections:
    section.footer.paragraphs[0].text = "方法與初步結果　｜　"
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    section.footer.paragraphs[0]._p.append(field)

doc.core_properties.title = "財務問答標註實驗設計與初步結果說明"
doc.core_properties.subject = "Protocol v1.1 方法與 Development 小規模實測"
doc.save(OUTPUT)
print(OUTPUT)
