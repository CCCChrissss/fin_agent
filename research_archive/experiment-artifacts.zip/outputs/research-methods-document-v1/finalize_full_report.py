from pathlib import Path
import json

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = HERE / "財務問答標註實驗設計與初步結果說明.docx"
OUTPUT = HERE / "財務問答標註實驗設計與完整實驗結果.docx"
RESULTS = ROOT / "outputs/regression60-once-v1"


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def borders(cell):
    tc_pr = cell._tc.get_or_add_tcPr()
    node = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        edge = OxmlElement(f"w:{side}")
        edge.set(qn("w:val"), "single")
        edge.set(qn("w:sz"), "4")
        edge.set(qn("w:color"), "D9D9D9")
        node.append(edge)
    tc_pr.append(node)


def format_cell(cell, header=False, alternate=False):
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    borders(cell)
    shade(cell, "1F4E78" if header else ("EDF3F8" if alternate else "FFFFFF"))
    mar = OxmlElement("w:tcMar")
    for side in ("top", "bottom", "left", "right"):
        item = OxmlElement(f"w:{side}")
        item.set(qn("w:w"), "55")
        item.set(qn("w:type"), "dxa")
        mar.append(item)
    cell._tc.get_or_add_tcPr().append(mar)
    for p in cell.paragraphs:
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in p.runs:
            run.font.size = Pt(8.5)
            run.bold = header
            if header:
                run.font.color.rgb = __import__("docx").shared.RGBColor(255, 255, 255)


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    table.autofit = False
    for cell, value, width in zip(table.rows[0].cells, headers, widths):
        cell.text = str(value)
        cell.width = Inches(width)
        format_cell(cell, header=True)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for row_no, values in enumerate(rows):
        row = table.add_row()
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for cell, value, width in zip(row.cells, values, widths):
            cell.text = str(value)
            cell.width = Inches(width)
            format_cell(cell, alternate=(row_no % 2 == 1))
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def page_heading(doc, text):
    p = doc.add_heading(text, level=1)
    p.paragraph_format.page_break_before = True


def pct(value):
    return "—" if value is None else f"{100 * value:.1f}%"


def load_finals(partition):
    path = RESULTS / partition / "evaluation-ai/per_question.jsonl"
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    finals = {}
    for row in rows:
        key = (row["condition"], row["question_id"])
        if key not in finals or row["attempt"] > finals[key]["attempt"]:
            finals[key] = row
    return list(finals.values())


summary = json.loads((RESULTS / "analysis-summary.json").read_text(encoding="utf-8"))
doc = Document(SOURCE)

doc.paragraphs[0].text = "財務問答標註實驗設計與完整實驗結果"
doc.paragraphs[0].style = doc.styles["Title"]
doc.paragraphs[3].text = (
    "本文件整合研究設計、標註欄位、題型代號、小規模驗證與 60 題固定版本回歸結果。"
    "完整回歸顯示，加入 deterministic validators 與 feedback retry 後，C、D 組最終 E2E 均為 85.0%；"
    "本次 D 組未比 C 組增加最終正確題數，因此 Judge 的效果應解讀為額外完成閘門，而非已證實的準確率提升。"
)
for p in doc.paragraphs:
    if p.text.startswith("整理日期"):
        p.text = (
            "整理日期：2026 年 9 月 17 日。方法版本：Protocol v1.1。"
            "主要結果來源：outputs/regression60-once-v1；小規模結果來源：outputs/dev-prompt-v4/full-dev-v4/final-report；"
            "Judge 診斷來源：outputs/dev-judge-diagnostic-v1。"
        )

page_heading(doc, "十六 60 題固定版本回歸實驗")
doc.add_paragraph(
    "正式彙整包含 12 題 Development Set 與 48 題歷史 Test Set，每題分別執行 A、B、C、D 一次，共 240 個 question-runs。"
    "本次依研究時程採單次執行，因此不報告 run 間標準差。Test Set 曾用於先前開發，故本結果屬固定版本回歸，不能宣稱為未接觸的 pristine holdout。"
    "語意項目由同一 gemma4:12b 以獨立 fresh context 進行 AI-assisted 離線審核，human_review_completed=false。"
)

combined = {row[0]: row for row in summary["combined"]}
add_table(
    doc,
    ("條件", "正確題數", "E2E", "主要流程差異"),
    (
        ("A", combined["A"][1], combined["A"][2], "共同輸出契約與事實搜尋，單次提交"),
        ("B", combined["B"][1], combined["B"][2], "A 加入結構化標註工作流程"),
        ("C", combined["C"][1], combined["C"][2], "B 加入 deterministic validators、feedback retry 與 gate"),
        ("D", combined["D"][1], combined["D"][2], "C 加入 fresh-context Semantic Judge 與 acceptance gate"),
    ),
    (0.55, 0.9, 0.8, 4.0),
)
doc.add_paragraph(
    "A 至 B 增加 11 題正確答案；B 至 C 再增加 30 題。C 與 D 均為 51／60，且逐題配對結果完全相同：51 題兩組皆正確、9 題兩組皆錯誤。"
    "因此目前最有力的實驗證據支持 validators 與 feedback retry，而沒有顯示 Semantic Judge 在這批自然題目中帶來額外準確率。"
)

page_heading(doc, "十七 Development 與歷史 Test 結果")
for partition, label in (("development", "Development 12 題"), ("test", "歷史 Test 48 題")):
    doc.add_heading(label, level=2)
    metrics = summary[partition]["metrics"]["metrics"]
    rows = []
    for condition in "ABCD":
        m = metrics[condition]
        rows.append((
            condition,
            pct(m["e2e_accuracy"]["mean"]),
            pct(m["first_pass_accuracy"]["mean"]),
            pct(m["answer_accuracy"]["mean"]),
            pct(m["evidence_f1"]["mean"]),
            pct(m["python_execution_rate"]["mean"]),
            pct(m["python_answer_consistency"]["mean"]),
            pct(m["recovery_rate"]["mean"]),
        ))
    add_table(doc, ("組", "E2E", "First", "Answer", "Evidence F1", "Python 執行", "Python 一致", "Recovery"), rows,
              (0.35, 0.62, 0.62, 0.7, 0.86, 0.85, 0.85, 0.8))

doc.add_paragraph(
    "Development 中 C、D 為 100.0%，到了歷史 Test 均降為 81.3%，顯示小規模 Development 的滿分不能直接外推。"
    "C、D 的 Test first-pass 均為 37.5%，final accuracy 為 81.3%，recovery rate 為 70.0%，說明主要增益來自失敗後的結構化修正。"
)

page_heading(doc, "十八 各題型準確率")
type_labels = {
    "Arithmetic": "AR 算術",
    "Comparison": "CP 比較",
    "Growth_Rate": "GR 成長率",
    "Logic": "LG 邏輯",
    "Ratio": "RT 比率",
    "Single-Fact": "SF 單一事實",
}
for partition, label in (("development", "Development"), ("test", "歷史 Test")):
    finals = load_finals(partition)
    doc.add_heading(label, level=2)
    rows = []
    for qtype in type_labels:
        values = []
        for condition in "ABCD":
            subset = [r for r in finals if r["condition"] == condition and r["question_type"] == qtype]
            correct = sum(r["e2e"] == 1 for r in subset)
            values.append(f"{correct}/{len(subset)}  {pct(correct / len(subset))}")
        rows.append((type_labels[qtype], *values))
    add_table(doc, ("題型", "A", "B", "C", "D"), rows, (1.35, 1.22, 1.22, 1.22, 1.22))

doc.add_paragraph(
    "歷史 Test 中，C、D 對 AR、GR、SF 均達 100%；CP 為 37.5%，LG 與 RT 為 75.0%。"
    "後續錯誤分析應優先檢查 Comparison 題型的比較方向、期間選擇與條件約束，而不是再擴充一般性 prompt。"
)

page_heading(doc, "十九 C 與 D 的實測差異")
add_table(
    doc,
    ("觀察", "C", "D", "解讀"),
    (
        ("60 題最終 E2E", "51／60", "51／60", "最終正誤完全一致"),
        ("Development attempts", "21", "22", "D 多 1 次生成嘗試"),
        ("Test attempts", "93", "93", "生成嘗試相同"),
        ("Test 完成狀態", "39 VALIDATED、9 FAILED", "39 ACCEPTED、9 FAILED", "D 改變通過狀態語意"),
        ("Test Judge requests", "0", "39", "D 對 deterministic pass 的答案呼叫 Judge"),
        ("Test Judge rejections", "不適用", "0", "自然題目未觀察到 Judge 拒絕"),
    ),
    (1.35, 1.35, 1.5, 2.15),
)
doc.add_paragraph(
    "本次自然資料中，D 的線上 Judge 沒有拒絕任何已通過 deterministic validators 的答案，所以 D 沒有改變 C 的最終結果。"
    "這不代表 Judge 沒有能力：獨立合成錯誤診斷中，gemma4:12b 對 9／9 個可判定語意錯誤皆有偵測，且對 12／12 個 control 全數接受。"
    "不過合成診斷只能證明局部判別能力，不能取代自然題目的增量效益證據。"
)

page_heading(doc, "二十 可信度限制與建議報告方式")
doc.add_paragraph(
    "本結果可作為目前凍結版本的可重現回歸證據，但不宜直接宣稱 D 顯著優於 C。主要限制包括：每格僅執行一次、Generator 與 Judge 使用同一模型家族、"
    "Test Set 曾參與開發歷程、語意標籤為 AI-assisted 而非完成人工複核，以及 C、D 的部分失敗可能同時受模型生成能力與最大重試限制影響。"
)
doc.add_paragraph(
    "論文中建議同時呈現總體 E2E、First-pass、Final、Recovery、題型分層與 C／D 逐題配對。對 D 的結論應寫為："
    "Semantic Judge 在受控錯誤診斷中能辨識語意錯誤，但在本次 60 題自然回歸中沒有產生相對 C 的額外正確題數；其成本與獨立模型偏誤仍需後續研究。"
)
doc.add_paragraph(
    "執行期間 B 組 RT08 曾因程序中斷而失敗；紀錄保留為 INTERRUPTED／FAILED 並納入分母，沒有重抽或刪除。"
    "所有模型參數、model digest、Ollama 版本、硬體資訊、attempt、validator、judge 與 final trace 均保留在輸出目錄。"
)

for section in doc.sections:
    footer = section.footer.paragraphs[0]
    footer.text = "實驗設計與完整結果  |  "
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)

doc.core_properties.title = "財務問答標註實驗設計與完整實驗結果"
doc.core_properties.subject = "TANET 2026 Protocol v1.1 方法與 60 題固定版本回歸"
doc.save(OUTPUT)
print(OUTPUT)
