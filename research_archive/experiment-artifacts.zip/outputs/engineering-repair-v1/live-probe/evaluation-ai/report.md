# Financial Annotation Evaluation

Mode: **live**. Question-runs: 10/10.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| C | 0.8 | 0.2 | 0.75 |
| D | 0.8 | 0.2 | 0.75 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
