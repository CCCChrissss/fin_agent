# Financial Annotation Evaluation

Mode: **live**. Question-runs: 144/144.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | 0.16666666666666666 | 0.16666666666666666 | 0.0 |
| B | 0 | 0 | 0.0 |
| C | 0.5 | 0 | 0.5 |
| D | 0.5 | 0 | 0.5 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
