# Financial Annotation Evaluation

Mode: **live**. Question-runs: 576/576.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | 0.10416666666666667 | 0.10416666666666667 | 0.0 |
| B | 0.020833333333333332 | 0.020833333333333332 | 0.0 |
| C | 0.125 | 0 | 0.125 |
| D | 0.125 | 0 | 0.125 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
