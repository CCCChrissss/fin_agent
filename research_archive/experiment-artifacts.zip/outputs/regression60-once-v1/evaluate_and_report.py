"""Post-generation measurement using existing frozen evaluation and review methods."""
import html
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT/'scripts'), str(ROOT/'src')]
import run_dev_prompt_v2 as workflow
from financial_annotation_harness.config import load_settings
from financial_annotation_harness.facts import FactRepository
from financial_annotation_harness.io_utils import read_json, read_jsonl, timestamp, file_hash
from financial_annotation_harness.trace import TraceStore

def status(phase, **details):
    value = dict(phase=phase, updated_at=timestamp(), pid=os.getpid(), **details)
    temp = BASE/'evaluation-status.tmp'
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(BASE/'evaluation-status.json')
    print(json.dumps(value, ensure_ascii=False), flush=True)

def table(headers, rows):
    return '<table><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</table>'

def pct(value):
    return '待評／不適用' if value is None else f'{value:.1%}'

def build_report():
    sections=[]; combined=defaultdict(list); final_sets={}; results={}
    for partition in ('development','test'):
        folder=BASE/partition
        scores=read_jsonl(folder/'evaluation-ai/per_question.jsonl')
        group=defaultdict(list)
        for row in scores: group[row['condition'],row['question_id']].append(row)
        finals={key:max(rows,key=lambda r:r['attempt']) for key,rows in group.items()}
        firsts={key:min(rows,key=lambda r:r['attempt']) for key,rows in group.items()}
        final_sets[partition]=finals
        metrics=read_json(folder/'evaluation-ai/aggregate_metrics.json')
        results[partition]={'metrics':metrics,'conditions':{},'paired_cd':{}}
        sections.append('<h2>'+('Development 12 題' if partition=='development' else '歷史 Test 48 題')+'</h2>')
        sections.append(table(['條件','正確／總題數','E2E','首輪','答案','Evidence F1','Python 一致','Recovery'],[
            [c,f"{sum(r['e2e']==1 for (k,q),r in finals.items() if k==c)}/{sum(k==c for k,q in finals)}"]+
            [pct(metrics['metrics'][c][key]['mean']) for key in ('e2e_accuracy','first_pass_accuracy','answer_accuracy','evidence_f1','python_answer_consistency','recovery_rate')]
            for c in 'ABCD']))
        bytype=[]
        for kind in ['Single-Fact','Comparison','Growth_Rate','Ratio','Logic','Arithmetic']:
            line=[kind]
            for c in 'ABCD':
                subset=[r for (k,q),r in finals.items() if k==c and r['question_type']==kind]
                line.append(f"{sum(r['e2e']==1 for r in subset)}/{len(subset)} ({pct(sum(r['e2e']==1 for r in subset)/len(subset))})")
            bytype.append(line)
        sections.append('<h3>各題型 E2E 正確題數</h3>'+table(['題型','A','B','C','D'],bytype))
        pairs=Counter(); detail=[]
        for c in 'ABCD':
            attempts=[]; events=[]
            for p in sorted(folder.glob(f'run_*/{c}/attempts.jsonl')):
                store=TraceStore(p.parent); attempts+=store.read('attempts');events+=store.read('events')
            selected=[r for (k,q),r in finals.items() if k==c]
            combined[c]+=selected
            records=[r for p in sorted(folder.glob(f'run_*/{c}/finals.jsonl')) for r in TraceStore(p.parent).read('finals')]
            counts={'attempts':len(attempts),'final_statuses':dict(Counter(r['final_status'] for r in records)),
                    'runtime_errors':dict(Counter(r.get('runtime_error_type') for r in attempts if r.get('runtime_error_type'))),
                    'judge_requests':sum(e['event']=='judge_request' for e in events),
                    'judge_rejections':sum(bool(r.get('judge_result')) and not r['judge_result']['overall_pass'] for r in attempts),
                    'first_correct_final_wrong':sum(firsts[c,r['question_id']]['e2e']==1 and r['e2e']==0 for r in selected)}
            results[partition]['conditions'][c]=counts
        for q in sorted(q for c,q in finals if c=='C'):
            a,b=finals['C',q],finals['D',q]
            key=f"C{'對' if a['e2e']==1 else '錯' if a['e2e']==0 else '待評'} D{'對' if b['e2e']==1 else '錯' if b['e2e']==0 else '待評'}"
            pairs[key]+=1;detail.append([q,a['question_type'],a['e2e'],b['e2e'],a['attempt'],b['attempt']])
        results[partition]['paired_cd']=dict(pairs)
        sections.append('<h3>C 與 D 配對比較</h3>'+table(['配對結果','題數'],pairs.items()))
        sections.append('<p>配對差異描述觀察結果，不能單憑 C 錯 D 對就歸因於 Judge；需確認 Judge 拒絕、回饋及下一輪改動。</p>')
        sections.append(table(['條件','總 attempts','Judge 呼叫','Judge 拒絕','首輪對終輪錯','Runtime errors'],[[c,*[results[partition]['conditions'][c][k] for k in ('attempts','judge_requests','judge_rejections','first_correct_final_wrong','runtime_errors')]] for c in 'ABCD']))
        sections.append('<details><summary>逐題 C／D 與終止 attempt</summary>'+table(['題號','題型','C E2E','D E2E','C attempt','D attempt'],detail)+'</details>')
    overall=[]
    for c,rows in combined.items():
        correct=sum(r['e2e']==1 for r in rows);pending=sum(r['e2e'] is None for r in rows)
        overall.append([c,f'{correct}/{len(rows)}',pct(correct/len(rows)) if not pending else '待評',pending])
    results['combined']=overall
    content='<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><title>60 題固定版本回歸結果</title><style>body{font:16px/1.7 "Microsoft JhengHei",sans-serif;max-width:1200px;margin:35px auto;padding:20px;color:#182737}table{border-collapse:collapse;width:100%;margin:18px 0}td,th{border:1px solid #ccd6df;padding:9px;text-align:left}th{background:#e4edf6}h2{margin-top:42px}summary{cursor:pointer}</style><h1>60 題固定版本回歸結果</h1><p>Protocol v1.1；60 題 × A/B/C/D × 1 次。Generator 與線上 Judge 均為 gemma4:12b。歷史 Test 已使用，屬固定版本回歸，非未接觸 holdout。單次 run 的跨 run SD 不適用。</p><p>客觀 Gold 比較與獨立 request 的 AI 語意審閱共同評分；非人工驗證。離線模型只看問題、產物及財務 facts，不看 Gold 或線上 Judge verdict。B 組 RT08 中斷失敗保留分母，不重抽。</p><h2>全部 60 題</h2>'+table(['條件','E2E 正確／題數','準確率','待評'],overall)+''.join(sections)+'<p>來源：各 partition 的 evaluation-ai、ai-review-labels.jsonl 與原始 events／attempts／finals。保留模型回應、rubric、review request 與雜湊以供追蹤。</p></html>'
    (BASE/'report.html').write_text(content,encoding='utf-8')
    (BASE/'analysis-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    return results

def main():
    workflow.status=status
    settings=load_settings(ROOT/'config/experiment.regression60-once.json')
    derived=ROOT/'artifacts/derived'/file_hash(ROOT/'data/financial_qa_gold_dataset_v2.xlsx')
    repo=FactRepository(derived/'financial_facts.sqlite')
    for partition in ('development','test'):
        workflow.OUT=BASE/partition
        status('MECHANICAL_EVALUATION',partition=partition)
        workflow.evaluate(workflow.OUT/'evaluation-mechanical')
    for partition in ('development','test'):
        workflow.OUT=BASE/partition
        if not (workflow.OUT/'evaluation-ai/aggregate_metrics.json').exists():
            status('OFFLINE_AI_REVIEW',partition=partition)
            workflow.offline_review(settings,repo)
    build_report()
    status('EVALUATION_AND_HTML_COMPLETE',word_update_pending=True)

if __name__=='__main__':
    try: main()
    except Exception as exc:
        status('FAILED',error=f'{type(exc).__name__}: {exc}')
        raise
