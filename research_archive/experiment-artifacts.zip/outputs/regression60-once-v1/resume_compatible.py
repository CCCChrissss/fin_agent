"""Resume with audited order-only normalization of Ollama parameter metadata."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
import run_regression60_once as original

release = ROOT / 'outputs/regression60-once-release-v1'
output = Path(__file__).resolve().parent
frozen = json.loads((release / 'freeze.json').read_text(encoding='utf-8'))['runtime']
Base = original.ReleaseProvider

class CompatibleProvider(Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        raw = self.runtime
        normalized = dict(raw)
        if sorted(raw['model_parameters'].splitlines()) != sorted(frozen['model_parameters'].splitlines()):
            raise ValueError('Model parameter values changed')
        normalized['model_parameters'] = frozen['model_parameters']
        if normalized != frozen:
            raise ValueError('Runtime change beyond parameter line order')
        audit = {'reason': 'Parameter metadata line order only; requests unchanged',
                 'raw_runtime': raw, 'comparison_runtime': normalized}
        with (output / 'resume-runtime-order-audit.json').open('x', encoding='utf-8') as handle:
            json.dump(audit, handle, ensure_ascii=False, indent=2)
        self.runtime = normalized

original.ReleaseProvider = CompatibleProvider
print(json.dumps(original.run(release, output, resume=True)), flush=True)
