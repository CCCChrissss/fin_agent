# Financial Annotation Evaluation

Mode: **live**. Question-runs: 192/192.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | 0.16666666666666666 | 0.16666666666666666 | 0.0 |
| B | 0.3541666666666667 | 0.3541666666666667 | 0.0 |
| C | 0.8125 | 0.375 | 0.7 |
| D | 0.8125 | 0.375 | 0.7 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
