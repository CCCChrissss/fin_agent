# Financial Annotation Evaluation

Mode: **live**. Question-runs: 144/144.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | 0.16666666666666666 | 0.16666666666666666 | 0.0 |
| B | 0.25 | 0.25 | 0.0 |
| C | 1 | 0.25 | 1.0 |
| D | 1 | 0.25 | 1.0 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
