# Financial Annotation Evaluation

Mode: **live**. Question-runs: 144/144.
Pending independent reviews: 198. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | None | None | None |
| B | None | None | None |
| C | None | None | None |
| D | None | None | None |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
