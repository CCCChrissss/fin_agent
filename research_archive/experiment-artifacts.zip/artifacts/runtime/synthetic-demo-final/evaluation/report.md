# Financial Annotation Evaluation

Mode: **synthetic_demo**. Question-runs: 12/12.
Pending independent reviews: 0. Null metrics are not zero.

| Condition | E2E mean | First-pass mean | Recovery mean |
|---|---:|---:|---:|
| A | 0 | 0 | 0.0 |
| B | 0 | 0 | 0.0 |
| C | 1 | 0 | 1.0 |
| D | 1 | 0 | 1.0 |

Only independently adjudicated components determine semantic correctness; online Judge PASS is not a Gold score.
FAILED outputs remain in the denominator. Scripted/demo results are software tests, not model-performance evidence.
