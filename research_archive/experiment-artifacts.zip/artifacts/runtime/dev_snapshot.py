from pathlib import Path
import sys, json
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'src'))
from financial_annotation_harness.io_utils import read_jsonl,read_json,file_hash,timestamp
from financial_annotation_harness.config import load_rules
from financial_annotation_harness.facts import FactRepository
from financial_annotation_harness.evaluation import score_attempt
derived=ROOT/'artifacts/derived'/file_hash(ROOT/'data/financial_qa_gold_dataset_v2.xlsx')
gold={r['question_id']:r for r in read_jsonl(derived/'gold_annotations.jsonl')}
questions={r['question_id']:{'question_id':r['question_id'],'question':r['zh'],'language':'zh'} for r in read_jsonl(derived/'question_inputs.jsonl')}
repo=FactRepository(derived/'financial_facts.sqlite')
rules=load_rules(ROOT)
result=[]
for cond in 'ABCD':
    folder=ROOT/'results/dev-ai-assisted-001/run_01'/cond
    finals=read_jsonl(folder/'finals.jsonl')
    if len(finals)!=12:
        continue
    attempts={r['record_hash']:r for r in read_jsonl(folder/'attempts.jsonl')}
    scores=[score_attempt(attempts[f['attempt_record_hash']],gold[f['question_id']],questions[gold[f['question_id']]['public_question_id']],repo,rules) for f in finals]
    result.append({'condition':cond,'run_index':1,'n':12,**{key:sum(s[key] for s in scores)/12 for key in ('schema_accuracy','answer_accuracy','evidence_f1','python_execution_rate','python_answer_consistency')},'e2e':'not adjudicated'})
report={'kind':'preliminary_development_only','timestamp':timestamp(),'test_results':False,'rows':result}
out=ROOT/'outputs/ai-assisted-study/dev-first-run-snapshot.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
