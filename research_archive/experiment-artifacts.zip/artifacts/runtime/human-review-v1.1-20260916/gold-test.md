# Gold 人工審查：test

狀態：PENDING。此文件僅為人工審查材料，沒有自動判定 Gold 正確。
Test 內容只供 Gold 審查，不得據此調整 prompt、Harness rules 或 Judge。不要把此文件交給線上 Generator／Judge。
另存填寫 labels 複本；保留原審查包與來源 hash。每題的四項評分及 reviewer 都需填寫。

## AR01 — Arithmetic

聯電114年的流動資產與非流動資產合計為多少？

Gold record hash: `460d8dbb2eef118e210aac6300740f7d1750128ae03e6f58af895c9af3392c21`

- Time：114年12月31日
- Concept：流動資產 + 非流動資產
- Filter：None
- Logic：addition
- Gold answer：578996009
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_current_assets | 流動資產 | 2025 | 204783258 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I85 |
| UMC_2025_non_current_assets | 非流動資產 | 2025 | 374212751 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I88 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 流動資產 | 204,783,258 |
| 非流動資產 | 374,212,751 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    current_assets_2025 = 204783258
    non_current_assets_2025 = 374212751
    result = current_assets_2025 + non_current_assets_2025
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR02 — Arithmetic

聯電113年的流動負債與非流動負債合計為多少？

Gold record hash: `46931905ba2e4e133cb73c2234f68610ef3bc4b6c35a78268a088e5cb6d068b5`

- Time：113年12月31日
- Concept：流動負債 + 非流動負債
- Filter：None
- Logic：addition
- Gold answer：192015673
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_current_liabilities | 流動負債 | 2024 | 75260189 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I93 |
| UMC_2024_non_current_liabilities | 非流動負債 | 2024 | 116755484 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I96 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 |
| :--- | ---: |
| 流動負債 | 75,260,189 |
| 非流動負債 | 116,755,484 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    current_liabilities_2024 = 75260189
    non_current_liabilities_2024 = 116755484
    result = current_liabilities_2024 + non_current_liabilities_2024
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR03 — Arithmetic

聯電112年度稅前淨利減去所得稅費用後為多少？

Gold record hash: `d0bd4b8adc6faab58b7daafa4c169403e32ec7693304936f3a3c980f1696995a`

- Time：112年度
- Concept：稅前淨利 - 所得稅費用
- Filter：None
- Logic：subtraction
- Gold answer：61439817
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_profit_before_tax | 稅前淨利（淨損） | 2023 | 70912228 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I41 |
| UMC_2023_income_tax_expense | 所得稅費用（利益） | 2023 | 9472411 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I44 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 |
| :--- | ---: |
| 稅前淨利（淨損） | 70,912,228 |
| 所得稅費用（利益） | 9,472,411 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    profit_before_tax_2023 = 70912228
    income_tax_expense_2023 = 9472411
    result = profit_before_tax_2023 - income_tax_expense_2023
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR04 — Arithmetic

聯電114年度營業收入減去營業成本後為多少？

Gold record hash: `c612b3b46280a97488c0aefec9523fd3da5747f9bc09e7447710bf2410ef93ce`

- Time：114年度
- Concept：營業收入 - 營業成本
- Filter：None
- Logic：subtraction
- Gold answer：68906499
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |
| UMC_2025_operating_cost | 營業成本 | 2025 | 168646700 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I10 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 營業收入 | 237,553,199 |
| 營業成本 | 168,646,700 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_revenue_2025 = 237553199
    operating_cost_2025 = 168646700
    result = operating_revenue_2025 - operating_cost_2025
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR05 — Arithmetic

聯電112至114年度的平均營業收入為多少？

Gold record hash: `84a0d6474cd0b4c41ccce0c57457e77fa0721ca6a6446a08ed9ce52115b927b6`

- Time：112至114年度
- Concept：營業收入
- Filter：None
- Logic：average
- Gold answer：230796261
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業收入 | 222,533,000 | 232,302,584 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_revenue_by_year = {
        2023: 222533000,
        2024: 232302584,
        2025: 237553199,
    }
    average_value = sum(operating_revenue_by_year.values()) / len(operating_revenue_by_year)
    return round(average_value, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR06 — Arithmetic

聯電112至114年度的基本每股盈餘合計為多少？

Gold record hash: `e118ec6633a4ab5f47827a50821666ee00056f604e8a03367d84898202c2c678`

- Time：112至114年度
- Concept：基本每股盈餘（元）
- Filter：None
- Logic：addition across years
- Gold answer：12.07
- Unit：元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_basic_eps | 基本每股盈餘（元） | 2023 | 4.93 | TWD | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I80 |
| UMC_2024_basic_eps | 基本每股盈餘（元） | 2024 | 3.8 | TWD | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I81 |
| UMC_2025_basic_eps | 基本每股盈餘（元） | 2025 | 3.34 | TWD | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I82 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 基本每股盈餘（元） | 4.93 | 3.8 | 3.34 |

來源單位：元

### Gold Python（此步驟未執行）

```python
def solution():
    basic_eps_by_year = {
        2023: 4.93,
        2024: 3.8,
        2025: 3.34,
    }
    total = sum(basic_eps_by_year.values())
    return round(total, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR08 — Arithmetic

聯電113年歸屬於母公司業主之權益合計與非控制權益相加為多少？

Gold record hash: `35fd5f3886842751670974238aa2645ce5b6edf67a207f81d77efaf800580b9a`

- Time：113年12月31日
- Concept：歸屬於母公司業主之權益合計 + 非控制權益
- Filter：None
- Logic：addition
- Gold answer：378185004
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_equity_parent | 歸屬於母公司業主之權益合計 | 2024 | 377928391 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I120 |
| UMC_2024_nci_equity | 非控制權益 | 2024 | 256613 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I126 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 |
| :--- | ---: |
| 歸屬於母公司業主之權益合計 | 377,928,391 |
| 非控制權益 | 256,613 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    equity_attributable_to_parent_2024 = 377928391
    non_controlling_interests_2024 = 256613
    result = equity_attributable_to_parent_2024 + non_controlling_interests_2024
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR10 — Arithmetic

聯電112年度營業利益比114年度高多少？

Gold record hash: `9b6e922f6fd2b3d12daf607f595d1a39c84396be057d6fe3a9cf7c9d2f0be270`

- Time：112與114年度
- Concept：營業利益（損失）
- Filter：None
- Logic：difference
- Gold answer：13941973
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_income | 營業利益（損失） | 2023 | 57890661 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I35 |
| UMC_2025_operating_income | 營業利益（損失） | 2025 | 43948688 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I37 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 114年 |
| :--- | ---: | ---: |
| 營業利益（損失） | 57,890,661 | 43,948,688 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_income_2023 = 57890661
    operating_income_2025 = 43948688
    difference = operating_income_2023 - operating_income_2025
    return difference
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP01 — Comparison

112至114年度中，聯電哪一年的營業收入最高？

Gold record hash: `6262d29f812ce8212982155c415619001a0af36f709580ede8899306869507de`

- Time：112至114年度
- Concept：營業收入
- Filter：None
- Logic：maximum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業收入 | 222,533,000 | 232,302,584 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_revenue_by_year = {
        2023: 222533000,
        2024: 232302584,
        2025: 237553199,
    }
    result_year = max(operating_revenue_by_year, key=operating_revenue_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP02 — Comparison

112至114年度中，聯電哪一年的營業利益最低？

Gold record hash: `fae0da80ff932a892179724a188844208251b1d7009b99207f89893f5c42f6ba`

- Time：112至114年度
- Concept：營業利益（損失）
- Filter：None
- Logic：minimum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_income | 營業利益（損失） | 2023 | 57890661 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I35 |
| UMC_2024_operating_income | 營業利益（損失） | 2024 | 51612570 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I36 |
| UMC_2025_operating_income | 營業利益（損失） | 2025 | 43948688 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I37 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業利益（損失） | 57,890,661 | 51,612,570 | 43,948,688 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_income_by_year = {
        2023: 57890661,
        2024: 51612570,
        2025: 43948688,
    }
    result_year = min(operating_income_by_year, key=operating_income_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP04 — Comparison

112至114年各年12月31日，聯電哪一年的負債總計最低？

Gold record hash: `686a68b8ff90393309de108514267fbb2d3cd30e6a6476d95113a837b56af951`

- Time：112至114年12月31日
- Concept：負債總計
- Filter：None
- Logic：minimum across years
- Gold answer：2024
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_liabilities | 負債總計 | 2023 | 199608355 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I98 |
| UMC_2024_total_liabilities | 負債總計 | 2024 | 192015673 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I99 |
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 負債總計 | 199,608,355 | 192,015,673 | 199,140,569 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_liabilities_by_year = {
        2023: 199608355,
        2024: 192015673,
        2025: 199140569,
    }
    result_year = min(total_liabilities_by_year, key=total_liabilities_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP06 — Comparison

112至114年各年12月31日，聯電哪一年的流動資產最低？

Gold record hash: `d9f179a319bb0b4c3b8215962a79bbda12687ba4a3cffec06707ac8cd197b115`

- Time：112至114年12月31日
- Concept：流動資產
- Filter：None
- Logic：minimum across years
- Gold answer：2024
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_current_assets | 流動資產 | 2023 | 216797392 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I83 |
| UMC_2024_current_assets | 流動資產 | 2024 | 189677884 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I84 |
| UMC_2025_current_assets | 流動資產 | 2025 | 204783258 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I85 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 流動資產 | 216,797,392 | 189,677,884 | 204,783,258 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    current_assets_by_year = {
        2023: 216797392,
        2024: 189677884,
        2025: 204783258,
    }
    result_year = min(current_assets_by_year, key=current_assets_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP07 — Comparison

112至114年度中，聯電哪一年的營業費用最高？

Gold record hash: `97e756b95307bf8151a15981ae8e24c1a694bfe586bab4dc220484bf4b192f16`

- Time：112至114年度
- Concept：營業費用
- Filter：None
- Logic：maximum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_expenses | 營業費用 | 2023 | 23855503 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I29 |
| UMC_2024_operating_expenses | 營業費用 | 2024 | 25365419 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I30 |
| UMC_2025_operating_expenses | 營業費用 | 2025 | 26947690 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I31 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業費用 | 23,855,503 | 25,365,419 | 26,947,690 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_expenses_by_year = {
        2023: 23855503,
        2024: 25365419,
        2025: 26947690,
    }
    result_year = max(operating_expenses_by_year, key=operating_expenses_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP08 — Comparison

112至114年度中，聯電哪一年的其他綜合損益淨額最高？

Gold record hash: `3189b2bc10b374c2037a080c6685e14c0ad5f50fadb4065b71b73a394a5649d7`

- Time：112至114年度
- Concept：其他綜合損益（淨額）
- Filter：None
- Logic：maximum across years
- Gold answer：2024
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_other_comprehensive_income | 其他綜合損益（淨額） | 2023 | 6417926 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I56 |
| UMC_2024_other_comprehensive_income | 其他綜合損益（淨額） | 2024 | 8300984 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I57 |
| UMC_2025_other_comprehensive_income | 其他綜合損益（淨額） | 2025 | -4859711 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I58 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 其他綜合損益（淨額） | 6,417,926 | 8,300,984 | -4,859,711 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_other_comprehensive_income_by_year = {
        2023: 6417926,
        2024: 8300984,
        2025: -4859711,
    }
    result_year = max(net_other_comprehensive_income_by_year, key=net_other_comprehensive_income_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP09 — Comparison

112至114年度中，聯電哪一年的淨利歸屬於非控制權益最低？

Gold record hash: `6a4082a0361d1cfa548a4e2da51e1d36d7040c5f88f7a0717be770a0a8ab6b9c`

- Time：112至114年度
- Concept：淨利歸屬於非控制權益
- Filter：None
- Logic：minimum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_profit_attributable_nci | 淨利歸屬於非控制權益 | 2023 | 450184 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I68 |
| UMC_2024_profit_attributable_nci | 淨利歸屬於非控制權益 | 2024 | -104674 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I69 |
| UMC_2025_profit_attributable_nci | 淨利歸屬於非控制權益 | 2025 | -181501 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I70 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 淨利歸屬於非控制權益 | 450,184 | -104,674 | -181,501 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_profit_attributable_to_nci_by_year = {
        2023: 450184,
        2024: -104674,
        2025: -181501,
    }
    result_year = min(net_profit_attributable_to_nci_by_year, key=net_profit_attributable_to_nci_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP10 — Comparison

112至114年各年12月31日，聯電哪一年的歸屬於母公司業主之權益合計最高？

Gold record hash: `ea88470e38ad57465bc6054b77411733635615dc7e7b2bada97d63eeafdc8dbd`

- Time：112至114年12月31日
- Concept：歸屬於母公司業主之權益合計
- Filter：None
- Logic：maximum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_equity_parent | 歸屬於母公司業主之權益合計 | 2023 | 359237713 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I119 |
| UMC_2024_equity_parent | 歸屬於母公司業主之權益合計 | 2024 | 377928391 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I120 |
| UMC_2025_equity_parent | 歸屬於母公司業主之權益合計 | 2025 | 379768265 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I121 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 歸屬於母公司業主之權益合計 | 359,237,713 | 377,928,391 | 379,768,265 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    equity_attributable_to_parent_by_year = {
        2023: 359237713,
        2024: 377928391,
        2025: 379768265,
    }
    result_year = max(equity_attributable_to_parent_by_year, key=equity_attributable_to_parent_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR01 — Growth_Rate

聯電113年度營業收入相較112年度的成長率為何？

Gold record hash: `39904520d86ba5573a2dcc4f81e349f0037a8c0b5fbd43ab8f03da7b93ce545e`

- Time：112至113年度
- Concept：營業收入
- Filter：None
- Logic：(new-old)/old
- Gold answer：4.39
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 |
| :--- | ---: | ---: |
| 營業收入 | 222,533,000 | 232,302,584 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_revenue_2023 = 222533000
    operating_revenue_2024 = 232302584
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (operating_revenue_2024 - operating_revenue_2023) / operating_revenue_2023
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR02 — Growth_Rate

聯電114年度營業收入相較113年度的成長率為何？

Gold record hash: `3c87c24c002227671367fbd6804fce299a70bb82fd974a948bb0673142bd520c`

- Time：113至114年度
- Concept：營業收入
- Filter：None
- Logic：(new-old)/old
- Gold answer：2.26
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 營業收入 | 232,302,584 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_revenue_2024 = 232302584
    operating_revenue_2025 = 237553199
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (operating_revenue_2025 - operating_revenue_2024) / operating_revenue_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR04 — Growth_Rate

聯電113年負債總計相較112年的成長率為何？

Gold record hash: `5d6ec3776d98ef1dee5fc94601fb8bb336a418c64da510bccae46cd9dfad65d1`

- Time：112至113年12月31日
- Concept：負債總計
- Filter：None
- Logic：(new-old)/old
- Gold answer：-3.8
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_liabilities | 負債總計 | 2023 | 199608355 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I98 |
| UMC_2024_total_liabilities | 負債總計 | 2024 | 192015673 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I99 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 |
| :--- | ---: | ---: |
| 負債總計 | 199,608,355 | 192,015,673 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_liabilities_2023 = 199608355
    total_liabilities_2024 = 192015673
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (total_liabilities_2024 - total_liabilities_2023) / total_liabilities_2023
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR05 — Growth_Rate

聯電114年度營業利益相較113年度的成長率為何？

Gold record hash: `dc9659f8c33bc8ea1caaeef6394e6cb1030fde68fcf357f0b5d9d746c4f823e4`

- Time：113至114年度
- Concept：營業利益（損失）
- Filter：None
- Logic：(new-old)/old
- Gold answer：-14.85
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_operating_income | 營業利益（損失） | 2024 | 51612570 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I36 |
| UMC_2025_operating_income | 營業利益（損失） | 2025 | 43948688 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I37 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 營業利益（損失） | 51,612,570 | 43,948,688 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_income_2024 = 51612570
    operating_income_2025 = 43948688
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (operating_income_2025 - operating_income_2024) / operating_income_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR07 — Growth_Rate

聯電114年度營業費用相較113年度的成長率為何？

Gold record hash: `1943ebb5ba93bb8df7690f68ec062212446ac1d0041c98333878182c241e6b0b`

- Time：113至114年度
- Concept：營業費用
- Filter：None
- Logic：(new-old)/old
- Gold answer：6.24
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_operating_expenses | 營業費用 | 2024 | 25365419 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I30 |
| UMC_2025_operating_expenses | 營業費用 | 2025 | 26947690 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I31 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 營業費用 | 25,365,419 | 26,947,690 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_expenses_2024 = 25365419
    operating_expenses_2025 = 26947690
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (operating_expenses_2025 - operating_expenses_2024) / operating_expenses_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR08 — Growth_Rate

聯電113年權益總計相較112年的成長率為何？

Gold record hash: `31f714b528e1e6f070ce48c74c5a4b4576ad94e089de879c837be094124c90a9`

- Time：112至113年12月31日
- Concept：權益總計
- Filter：None
- Logic：(new-old)/old
- Gold answer：5.17
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_equity | 權益總計 | 2023 | 359578572 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I128 |
| UMC_2024_total_equity | 權益總計 | 2024 | 378185004 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I129 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 |
| :--- | ---: | ---: |
| 權益總計 | 359,578,572 | 378,185,004 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_equity_2023 = 359578572
    total_equity_2024 = 378185004
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (total_equity_2024 - total_equity_2023) / total_equity_2023
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR09 — Growth_Rate

聯電114年度本期淨利相較113年度的成長率為何？

Gold record hash: `ae77a9bb297cab0a56c345e45fd50ac8909b7c067f1e3e075826486f4b228a69`

- Time：113至114年度
- Concept：本期淨利（淨損）
- Filter：None
- Logic：(new-old)/old
- Gold answer：-11.83
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_net_profit | 本期淨利（淨損） | 2024 | 47106256 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I54 |
| UMC_2025_net_profit | 本期淨利（淨損） | 2025 | 41534748 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I55 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 本期淨利（淨損） | 47,106,256 | 41,534,748 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_profit_2024 = 47106256
    net_profit_2025 = 41534748
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (net_profit_2025 - net_profit_2024) / net_profit_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR10 — Growth_Rate

聯電114年度基本每股盈餘相較113年度的成長率為何？

Gold record hash: `f847c899226ee2059ae137b1de0a2f1193663dc683376c981d9218ac0369e756`

- Time：113至114年度
- Concept：基本每股盈餘（元）
- Filter：None
- Logic：(new-old)/old
- Gold answer：-12.11
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_basic_eps | 基本每股盈餘（元） | 2024 | 3.8 | TWD | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I81 |
| UMC_2025_basic_eps | 基本每股盈餘（元） | 2025 | 3.34 | TWD | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I82 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 基本每股盈餘（元） | 3.8 | 3.34 |

來源單位：元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    basic_eps_2024 = 3.8
    basic_eps_2025 = 3.34
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (basic_eps_2025 - basic_eps_2024) / basic_eps_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG02 — Logic

聯電113年的資產總計是否高於112年？

Gold record hash: `f795196c384e1c6e99792bdfb416a24a728180bd4e2f11a5ae2b741eb16145c6`

- Time：112至113年12月31日
- Concept：資產總計
- Filter：None
- Logic：greater-than comparison
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_assets | 資產總計 | 2023 | 559186927 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I89 |
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 |
| :--- | ---: | ---: |
| 資產總計 | 559,186,927 | 570,200,677 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    total_assets_2023 = 559186927
    total_assets_2024 = 570200677
    return 'Yes' if total_assets_2024 > total_assets_2023 else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG04 — Logic

聯電114年度的其他綜合損益淨額是否為負數？

Gold record hash: `b2bf02295dbe3578f2ee1e61d75fbbee420fc60c298054153b4f071718c4bcf9`

- Time：114年度
- Concept：其他綜合損益（淨額）
- Filter：None
- Logic：value < 0
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_other_comprehensive_income | 其他綜合損益（淨額） | 2025 | -4859711 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I58 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 其他綜合損益（淨額） | -4,859,711 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    net_other_comprehensive_income_2025 = -4859711
    return 'Yes' if net_other_comprehensive_income_2025 < 0 else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG05 — Logic

聯電114年的負債總計是否低於權益總計？

Gold record hash: `3bd448297886ab239b2c5b67fdd614c95c5576a273af969a54ef6388e1e8db97`

- Time：114年12月31日
- Concept：負債總計 vs 權益總計
- Filter：None
- Logic：less-than comparison
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |
| UMC_2025_total_equity | 權益總計 | 2025 | 379855440 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I130 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 負債總計 | 199,140,569 |
| 權益總計 | 379,855,440 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    total_liabilities_2025 = 199140569
    total_equity_2025 = 379855440
    return 'Yes' if total_liabilities_2025 < total_equity_2025 else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG06 — Logic

112至114年中，聯電是否有任何一年的流動資產超過資產總計的40%？

Gold record hash: `dfcbaf629b23547d233dfff970304f7af566c7ff92272c6b195ed9679c384d38`

- Time：112至114年12月31日
- Concept：流動資產 / 資產總計
- Filter：40%
- Logic：any ratio > threshold
- Gold answer：No
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_current_assets | 流動資產 | 2023 | 216797392 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I83 |
| UMC_2024_current_assets | 流動資產 | 2024 | 189677884 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I84 |
| UMC_2025_current_assets | 流動資產 | 2025 | 204783258 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I85 |
| UMC_2023_total_assets | 資產總計 | 2023 | 559186927 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I89 |
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 流動資產 | 216,797,392 | 189,677,884 | 204,783,258 |
| 資產總計 | 559,186,927 | 570,200,677 | 578,996,009 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    current_assets_by_year = {
        2023: 216797392,
        2024: 189677884,
        2025: 204783258,
    }
    total_assets_by_year = {
        2023: 559186927,
        2024: 570200677,
        2025: 578996009,
    }
    threshold = 0.40
    exceeds = any((current_assets_by_year[year] / total_assets_by_year[year]) > threshold for year in current_assets_by_year)
    return 'Yes' if exceeds else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG07 — Logic

聯電112至114年度的營業費用是否逐年增加？

Gold record hash: `3b1d1560d7492ea8bcdd609093429abbcf676b4d58476029802db321c5c3b7ce`

- Time：112至114年度
- Concept：營業費用
- Filter：None
- Logic：monotonic increasing
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_expenses | 營業費用 | 2023 | 23855503 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I29 |
| UMC_2024_operating_expenses | 營業費用 | 2024 | 25365419 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I30 |
| UMC_2025_operating_expenses | 營業費用 | 2025 | 26947690 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I31 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業費用 | 23,855,503 | 25,365,419 | 26,947,690 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_expenses_by_year = {
        2023: 23855503,
        2024: 25365419,
        2025: 26947690,
    }
    ordered_values = [operating_expenses_by_year[year] for year in sorted(operating_expenses_by_year)]
    is_increasing = all(earlier < later for earlier, later in zip(ordered_values, ordered_values[1:]))
    return 'Yes' if is_increasing else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG08 — Logic

聯電112至114年度是否每年都呈現營業收入增加、但營業利益下降？

Gold record hash: `89ea5e3877ac1b57aeed2960fdbc104bd1b92bf618b0bb1019f7176edaab32ee`

- Time：112至114年度
- Concept：營業收入；營業利益（損失）
- Filter：None
- Logic：revenue monotonic increasing AND operating income monotonic decreasing
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |
| UMC_2023_operating_income | 營業利益（損失） | 2023 | 57890661 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I35 |
| UMC_2024_operating_income | 營業利益（損失） | 2024 | 51612570 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I36 |
| UMC_2025_operating_income | 營業利益（損失） | 2025 | 43948688 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I37 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業收入 | 222,533,000 | 232,302,584 | 237,553,199 |
| 營業利益（損失） | 57,890,661 | 51,612,570 | 43,948,688 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_revenue_by_year = {
        2023: 222533000,
        2024: 232302584,
        2025: 237553199,
    }
    operating_income_by_year = {
        2023: 57890661,
        2024: 51612570,
        2025: 43948688,
    }
    revenue_values = [operating_revenue_by_year[year] for year in sorted(operating_revenue_by_year)]
    income_values = [operating_income_by_year[year] for year in sorted(operating_income_by_year)]
    revenue_increasing = all(a < b for a, b in zip(revenue_values, revenue_values[1:]))
    income_decreasing = all(a > b for a, b in zip(income_values, income_values[1:]))
    return 'Yes' if revenue_increasing and income_decreasing else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG09 — Logic

聯電112至114年度的營業毛利率是否逐年下降？

Gold record hash: `25fef30c2fca5cc9913e9dc4a15e508205ee65010dcbec9dd9ba0d6457d48307`

- Time：112至114年度
- Concept：營業毛利（毛損） / 營業收入
- Filter：None
- Logic：compute yearly ratio, then monotonic decreasing
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_gross_profit | 營業毛利（毛損） | 2023 | 77743838 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I17 |
| UMC_2024_gross_profit | 營業毛利（毛損） | 2024 | 75654080 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I18 |
| UMC_2025_gross_profit | 營業毛利（毛損） | 2025 | 68906499 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I19 |
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 營業毛利（毛損） | 77,743,838 | 75,654,080 | 68,906,499 |
| 營業收入 | 222,533,000 | 232,302,584 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    gross_profit_by_year = {
        2023: 77743838,
        2024: 75654080,
        2025: 68906499,
    }
    operating_revenue_by_year = {
        2023: 222533000,
        2024: 232302584,
        2025: 237553199,
    }
    gross_margin_by_year = {year: gross_profit_by_year[year] / operating_revenue_by_year[year] for year in gross_profit_by_year}
    ordered_margins = [gross_margin_by_year[year] for year in sorted(gross_margin_by_year)]
    is_decreasing = all(a > b for a, b in zip(ordered_margins, ordered_margins[1:]))
    return 'Yes' if is_decreasing else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG10 — Logic

聯電114年的資產總計是否等於負債總計加上權益總計？

Gold record hash: `83f577cb6c7696a2df4cd40a702d9896a8f6ab08d9865c4966afbf54299cd415`

- Time：114年12月31日
- Concept：資產總計；負債總計；權益總計
- Filter：None
- Logic：equality check
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |
| UMC_2025_total_equity | 權益總計 | 2025 | 379855440 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I130 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 資產總計 | 578,996,009 |
| 負債總計 | 199,140,569 |
| 權益總計 | 379,855,440 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    total_assets_2025 = 578996009
    total_liabilities_2025 = 199140569
    total_equity_2025 = 379855440
    return 'Yes' if total_assets_2025 == total_liabilities_2025 + total_equity_2025 else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT01 — Ratio

聯電114年流動資產占資產總計的比例為何？

Gold record hash: `07a7d3ba2b65c676501a98de0b49f81c0fd88bf0fb27ef79f0baa7d5b729522c`

- Time：114年12月31日
- Concept：流動資產 / 資產總計
- Filter：None
- Logic：part/total
- Gold answer：35.37
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_current_assets | 流動資產 | 2025 | 204783258 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I85 |
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 流動資產 | 204,783,258 |
| 資產總計 | 578,996,009 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    current_assets_2025 = 204783258
    total_assets_2025 = 578996009
    # Reasoning：比例 = 分子 / 分母
    ratio = current_assets_2025 / total_assets_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT02 — Ratio

聯電114年流動負債占負債總計的比例為何？

Gold record hash: `fc563b0aaf7a2efbe9a591963d60bac45782a143ce1a2936326e5f3771aa2b2f`

- Time：114年12月31日
- Concept：流動負債 / 負債總計
- Filter：None
- Logic：part/total
- Gold answer：43.99
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_current_liabilities | 流動負債 | 2025 | 87598137 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I94 |
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 流動負債 | 87,598,137 |
| 負債總計 | 199,140,569 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    current_liabilities_2025 = 87598137
    total_liabilities_2025 = 199140569
    # Reasoning：比例 = 分子 / 分母
    ratio = current_liabilities_2025 / total_liabilities_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT03 — Ratio

聯電114年度營業毛利占營業收入的比例為何？

Gold record hash: `6e2afb71547baaa52e10042968fc682c1388314d6ab8a63f4ffabb92297773e5`

- Time：114年度
- Concept：營業毛利 / 營業收入
- Filter：None
- Logic：part/total
- Gold answer：29.01
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_gross_profit | 營業毛利（毛損） | 2025 | 68906499 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I19 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 營業毛利（毛損） | 68,906,499 |
| 營業收入 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    gross_profit_2025 = 68906499
    operating_revenue_2025 = 237553199
    # Reasoning：比例 = 分子 / 分母
    ratio = gross_profit_2025 / operating_revenue_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT05 — Ratio

聯電112年度本期淨利占營業收入的比例為何？

Gold record hash: `208167f0ac754e7e2789b98431872dae5cd4d351ff87bd15328cd0690c48f4bd`

- Time：112年度
- Concept：本期淨利 / 營業收入
- Filter：None
- Logic：part/total
- Gold answer：27.61
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_net_profit | 本期淨利（淨損） | 2023 | 61439817 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I53 |
| UMC_2023_operating_revenue | 營業收入 | 2023 | 222533000 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I5 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 |
| :--- | ---: |
| 本期淨利（淨損） | 61,439,817 |
| 營業收入 | 222,533,000 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_profit_2023 = 61439817
    operating_revenue_2023 = 222533000
    # Reasoning：比例 = 分子 / 分母
    ratio = net_profit_2023 / operating_revenue_2023
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT06 — Ratio

聯電114年負債總計占資產總計的比例為何？

Gold record hash: `c57f9b2575e291a3535911b8c596cb67506d7d6e0e070939c63aa357f3faae8f`

- Time：114年12月31日
- Concept：負債總計 / 資產總計
- Filter：None
- Logic：part/total
- Gold answer：34.39
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 負債總計 | 199,140,569 |
| 資產總計 | 578,996,009 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_liabilities_2025 = 199140569
    total_assets_2025 = 578996009
    # Reasoning：比例 = 分子 / 分母
    ratio = total_liabilities_2025 / total_assets_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT08 — Ratio

聯電114年度營業費用占營業收入的比例為何？

Gold record hash: `1fdedda55de2ab368c3dc54a7bd2e04256c61ca38feae4fa7dc59cbc0fdac0dc`

- Time：114年度
- Concept：營業費用 / 營業收入
- Filter：None
- Logic：part/total
- Gold answer：11.34
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_operating_expenses | 營業費用 | 2025 | 26947690 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I31 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 營業費用 | 26,947,690 |
| 營業收入 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_expenses_2025 = 26947690
    operating_revenue_2025 = 237553199
    # Reasoning：比例 = 分子 / 分母
    ratio = operating_expenses_2025 / operating_revenue_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT09 — Ratio

聯電112年度所得稅費用占稅前淨利的比例為何？

Gold record hash: `9709474253fb243b89a8b52c3fc3ba131caa41a2637a7545304d13c7e82d8a0b`

- Time：112年度
- Concept：所得稅費用 / 稅前淨利
- Filter：None
- Logic：part/total
- Gold answer：13.36
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_income_tax_expense | 所得稅費用（利益） | 2023 | 9472411 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I44 |
| UMC_2023_profit_before_tax | 稅前淨利（淨損） | 2023 | 70912228 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I41 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 |
| :--- | ---: |
| 所得稅費用（利益） | 9,472,411 |
| 稅前淨利（淨損） | 70,912,228 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    income_tax_expense_2023 = 9472411
    profit_before_tax_2023 = 70912228
    # Reasoning：比例 = 分子 / 分母
    ratio = income_tax_expense_2023 / profit_before_tax_2023
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT10 — Ratio

聯電114年非控制權益占權益總計的比例為何？

Gold record hash: `2d172b297c780a162da4230599769798e5a8419cb5f7d4bd9fe85ae07ae1df27`

- Time：114年12月31日
- Concept：非控制權益 / 權益總計
- Filter：資產負債表
- Logic：part/total
- Gold answer：0.02
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_nci_equity | 非控制權益 | 2025 | 87175 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I127 |
| UMC_2025_total_equity | 權益總計 | 2025 | 379855440 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I130 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 非控制權益 | 87,175 |
| 權益總計 | 379,855,440 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    non_controlling_interests_2025 = 87175
    total_equity_2025 = 379855440
    # Reasoning：比例 = 分子 / 分母
    ratio = non_controlling_interests_2025 / total_equity_2025
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF01 — Single-Fact

聯電114年度的營業收入是多少？

Gold record hash: `32aeddc68be9cebaea88aba3f7ecc430dc588703d4bfcb8e18c850e7cdf382b0`

- Time：114年度
- Concept：營業收入
- Filter：None
- Logic：direct retrieval
- Gold answer：237553199
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 營業收入 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_revenue_2025 = 237553199
    return operating_revenue_2025
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF02 — Single-Fact

聯電113年12月31日的資產總計是多少？

Gold record hash: `e1f74844cdb921aeba6b6ba2a5e686bf135175da0be7745b8c4d8d03a4ac8fa1`

- Time：113年12月31日
- Concept：資產總計
- Filter：None
- Logic：direct retrieval
- Gold answer：570200677
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 |
| :--- | ---: |
| 資產總計 | 570,200,677 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_assets_2024 = 570200677
    return total_assets_2024
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF03 — Single-Fact

聯電112年度的本期淨利是多少？

Gold record hash: `b0e62c136ee815c9481f7e35ed52f00e10f33822ee0759f6be77c35ef9d78005`

- Time：112年度
- Concept：本期淨利（淨損）
- Filter：None
- Logic：direct retrieval
- Gold answer：61439817
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_net_profit | 本期淨利（淨損） | 2023 | 61439817 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I53 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 |
| :--- | ---: |
| 本期淨利（淨損） | 61,439,817 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_profit_2023 = 61439817
    return net_profit_2023
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF04 — Single-Fact

聯電114年12月31日的流動負債是多少？

Gold record hash: `5f700f74acfd5e31adc97609ce577cc9a6370a91f4387e89928d780d1088f115`

- Time：114年12月31日
- Concept：流動負債
- Filter：None
- Logic：direct retrieval
- Gold answer：87598137
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_current_liabilities | 流動負債 | 2025 | 87598137 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I94 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 流動負債 | 87,598,137 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    current_liabilities_2025 = 87598137
    return current_liabilities_2025
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF05 — Single-Fact

聯電113年12月31日的權益總計是多少？

Gold record hash: `cdd4f2b7b78dbb44006e65e8e3e969db12d640908595fa2154c293f3ed6201a0`

- Time：113年12月31日
- Concept：權益總計
- Filter：None
- Logic：direct retrieval
- Gold answer：378185004
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_total_equity | 權益總計 | 2024 | 378185004 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I129 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 |
| :--- | ---: |
| 權益總計 | 378,185,004 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_equity_2024 = 378185004
    return total_equity_2024
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF07 — Single-Fact

聯電114年度的基本每股盈餘是多少？

Gold record hash: `727bdf6e7b0a9551ae8c613dc959539fedf90271503128eb241a5b964841321c`

- Time：114年度
- Concept：基本每股盈餘（元）
- Filter：None
- Logic：direct retrieval
- Gold answer：3.34
- Unit：元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_basic_eps | 基本每股盈餘（元） | 2025 | 3.34 | TWD | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I82 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 基本每股盈餘（元） | 3.34 |

來源單位：元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    basic_eps_2025 = 3.34
    return basic_eps_2025
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF08 — Single-Fact

聯電113年度歸屬於母公司業主之綜合損益總額是多少？

Gold record hash: `5b076e00edd7dc4b8bd1cdace930a956031d8e0b72a3a22d6f985d87aeaa3972`

- Time：113年度
- Concept：綜合損益總額歸屬於母公司業主
- Filter：None
- Logic：direct retrieval
- Gold answer：55511838
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_comprehensive_income_parent | 綜合損益總額歸屬於母公司業主 | 2024 | 55511838 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I72 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 |
| :--- | ---: |
| 綜合損益總額歸屬於母公司業主 | 55,511,838 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_comprehensive_income_attributable_to_parent_2024 = 55511838
    return total_comprehensive_income_attributable_to_parent_2024
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF10 — Single-Fact

聯電112年12月31日資產負債表中的非控制權益是多少？

Gold record hash: `da92594fffedef897e03ea4f1664423497782e60db6a3c7b65c7608390a8e30a`

- Time：112年12月31日
- Concept：非控制權益
- Filter：資產負債表
- Logic：direct retrieval
- Gold answer：340859
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_nci_equity | 非控制權益 | 2023 | 340859 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I125 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 |
| :--- | ---: |
| 非控制權益 | 340,859 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    non_controlling_interests_2023 = 340859
    return non_controlling_interests_2023
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________
