# Gold 人工審查：development

狀態：PENDING。此文件僅為人工審查材料，沒有自動判定 Gold 正確。
Test 內容只供 Gold 審查，不得據此調整 prompt、Harness rules 或 Judge。不要把此文件交給線上 Generator／Judge。
另存填寫 labels 複本；保留原審查包與來源 hash。每題的四項評分及 reviewer 都需填寫。

## AR07 — Arithmetic

聯電114年的資產總計減去負債總計後為多少？

Gold record hash: `5e03849fefa9bbf6ffaf3ddea409283d8006d1a3fc4fd6805bf8a1e78ae19ace`

- Time：114年12月31日
- Concept：資產總計 - 負債總計
- Filter：None
- Logic：subtraction
- Gold answer：379855440
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |
| UMC_2025_total_liabilities | 負債總計 | 2025 | 199140569 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I100 |

### Gold Context

## 簡明資產負債表
| 項目 | 114年 |
| :--- | ---: |
| 資產總計 | 578,996,009 |
| 負債總計 | 199,140,569 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    total_assets_2025 = 578996009
    total_liabilities_2025 = 199140569
    result = total_assets_2025 - total_liabilities_2025
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## AR09 — Arithmetic

聯電114年度本期淨利與其他綜合損益淨額相加為多少？

Gold record hash: `8d2c0d485641521f4f82ca6638744adac3ffaaa4cd4b16ba31c4bd6354305f01`

- Time：114年度
- Concept：本期淨利 + 其他綜合損益
- Filter：None
- Logic：addition
- Gold answer：36675037
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_net_profit | 本期淨利（淨損） | 2025 | 41534748 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I55 |
| UMC_2025_other_comprehensive_income | 其他綜合損益（淨額） | 2025 | -4859711 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I58 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 本期淨利（淨損） | 41,534,748 |
| 其他綜合損益（淨額） | -4,859,711 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    net_profit_2025 = 41534748
    net_other_comprehensive_income_2025 = -4859711
    result = net_profit_2025 + net_other_comprehensive_income_2025
    return result
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP03 — Comparison

112至114年各年12月31日，聯電哪一年的資產總計最高？

Gold record hash: `3270bbe03801cb407f43e4d780ea9bbcd3ee2cc3722bec4d8d0eb15c5f516383`

- Time：112至114年12月31日
- Concept：資產總計
- Filter：None
- Logic：maximum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_assets | 資產總計 | 2023 | 559186927 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I89 |
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 資產總計 | 559,186,927 | 570,200,677 | 578,996,009 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_assets_by_year = {
        2023: 559186927,
        2024: 570200677,
        2025: 578996009,
    }
    result_year = max(total_assets_by_year, key=total_assets_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## CP05 — Comparison

112至114年各年12月31日，聯電哪一年的權益總計最高？

Gold record hash: `f6fc6256889fcdb0475dde22b9c0076ff1539503a18c59a92e78c679e550d501`

- Time：112至114年12月31日
- Concept：權益總計
- Filter：None
- Logic：maximum across years
- Gold answer：2025
- Unit：年

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_total_equity | 權益總計 | 2023 | 359578572 | TWD_thousand | instant: None ~ 2023-12-31 | 02_Financial_Facts!I128 |
| UMC_2024_total_equity | 權益總計 | 2024 | 378185004 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I129 |
| UMC_2025_total_equity | 權益總計 | 2025 | 379855440 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I130 |

### Gold Context

## 簡明資產負債表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 權益總計 | 359,578,572 | 378,185,004 | 379,855,440 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_equity_by_year = {
        2023: 359578572,
        2024: 378185004,
        2025: 379855440,
    }
    result_year = max(total_equity_by_year, key=total_equity_by_year.get)
    return result_year
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR03 — Growth_Rate

聯電114年資產總計相較113年的成長率為何？

Gold record hash: `de5dafcc66973bfb71ddff3d89a0cdf7e93ade8d5fc7e8130a08b6d1e27b80f0`

- Time：113至114年12月31日
- Concept：資產總計
- Filter：None
- Logic：(new-old)/old
- Gold answer：1.54
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |
| UMC_2025_total_assets | 資產總計 | 2025 | 578996009 | TWD_thousand | instant: None ~ 2025-12-31 | 02_Financial_Facts!I91 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 資產總計 | 570,200,677 | 578,996,009 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_assets_2024 = 570200677
    total_assets_2025 = 578996009
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (total_assets_2025 - total_assets_2024) / total_assets_2024
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## GR06 — Growth_Rate

聯電113年度營業毛利相較112年度的成長率為何？

Gold record hash: `a4ed642ff7a09f1114c6263d0681f967ec1f963c99cf4161167f5b62de6cea1c`

- Time：112至113年度
- Concept：營業毛利（毛損）
- Filter：None
- Logic：(new-old)/old
- Gold answer：-2.69
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_gross_profit | 營業毛利（毛損） | 2023 | 77743838 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I17 |
| UMC_2024_gross_profit | 營業毛利（毛損） | 2024 | 75654080 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I18 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 |
| :--- | ---: | ---: |
| 營業毛利（毛損） | 77,743,838 | 75,654,080 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    gross_profit_2023 = 77743838
    gross_profit_2024 = 75654080
    # Reasoning：成長率 = (新期 - 舊期) / 舊期
    growth_rate = (gross_profit_2024 - gross_profit_2023) / gross_profit_2023
    return round(growth_rate * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG01 — Logic

聯電114年度的營業收入是否高於113年度？

Gold record hash: `8831346f1c9da50eb4ae5686bdf5f91676a08ff7767930936c504932b838b22e`

- Time：113至114年度
- Concept：營業收入
- Filter：None
- Logic：greater-than comparison
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |
| UMC_2025_operating_revenue | 營業收入 | 2025 | 237553199 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I7 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 | 114年 |
| :--- | ---: | ---: |
| 營業收入 | 232,302,584 | 237,553,199 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    operating_revenue_2024 = 232302584
    operating_revenue_2025 = 237553199
    return 'Yes' if operating_revenue_2025 > operating_revenue_2024 else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## LG03 — Logic

聯電112至114年度的本期淨利是否逐年下降？

Gold record hash: `a282533f7a786c91486226b4e66dca907f3c1d9e196173a7d6a11b2d1df74310`

- Time：112至114年度
- Concept：本期淨利（淨損）
- Filter：None
- Logic：monotonic decreasing
- Gold answer：Yes
- Unit：Yes/No

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_net_profit | 本期淨利（淨損） | 2023 | 61439817 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I53 |
| UMC_2024_net_profit | 本期淨利（淨損） | 2024 | 47106256 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I54 |
| UMC_2025_net_profit | 本期淨利（淨損） | 2025 | 41534748 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I55 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 | 113年 | 114年 |
| :--- | ---: | ---: | ---: |
| 本期淨利（淨損） | 61,439,817 | 47,106,256 | 41,534,748 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    net_profit_by_year = {
        2023: 61439817,
        2024: 47106256,
        2025: 41534748,
    }
    ordered_values = [net_profit_by_year[year] for year in sorted(net_profit_by_year)]
    is_decreasing = all(earlier > later for earlier, later in zip(ordered_values, ordered_values[1:]))
    return 'Yes' if is_decreasing else 'No'
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT04 — Ratio

聯電113年度營業利益占營業收入的比例為何？

Gold record hash: `ff5cc0c0366be6ffbc21cbc808c095b4b27a4f76b0a427b4c11f1db347e02d80`

- Time：113年度
- Concept：營業利益 / 營業收入
- Filter：None
- Logic：part/total
- Gold answer：22.22
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_operating_income | 營業利益（損失） | 2024 | 51612570 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I36 |
| UMC_2024_operating_revenue | 營業收入 | 2024 | 232302584 | TWD_thousand | duration: 2024-01-01 ~ 2024-12-31 | 02_Financial_Facts!I6 |

### Gold Context

## 簡明綜合損益表
| 項目 | 113年 |
| :--- | ---: |
| 營業利益（損失） | 51,612,570 |
| 營業收入 | 232,302,584 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_income_2024 = 51612570
    operating_revenue_2024 = 232302584
    # Reasoning：比例 = 分子 / 分母
    ratio = operating_income_2024 / operating_revenue_2024
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## RT07 — Ratio

聯電113年權益總計占資產總計的比例為何？

Gold record hash: `5a598cdf6a19508cbacfc19320dde98517963cb7f9cc0532e9bc5c1a0c714a64`

- Time：113年12月31日
- Concept：權益總計 / 資產總計
- Filter：None
- Logic：part/total
- Gold answer：66.32
- Unit：%

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2024_total_equity | 權益總計 | 2024 | 378185004 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I129 |
| UMC_2024_total_assets | 資產總計 | 2024 | 570200677 | TWD_thousand | instant: None ~ 2024-12-31 | 02_Financial_Facts!I90 |

### Gold Context

## 簡明資產負債表
| 項目 | 113年 |
| :--- | ---: |
| 權益總計 | 378,185,004 |
| 資產總計 | 570,200,677 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    total_equity_2024 = 378185004
    total_assets_2024 = 570200677
    # Reasoning：比例 = 分子 / 分母
    ratio = total_equity_2024 / total_assets_2024
    return round(ratio * 100, 2)
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF06 — Single-Fact

聯電112年度的營業利益是多少？

Gold record hash: `3ce4ca90e0b9ff059f5945db7a9aac327df2f03ab63f14e5d7f6ae12c292d39e`

- Time：112年度
- Concept：營業利益（損失）
- Filter：None
- Logic：direct retrieval
- Gold answer：57890661
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2023_operating_income | 營業利益（損失） | 2023 | 57890661 | TWD_thousand | duration: 2023-01-01 ~ 2023-12-31 | 02_Financial_Facts!I35 |

### Gold Context

## 簡明綜合損益表
| 項目 | 112年 |
| :--- | ---: |
| 營業利益（損失） | 57,890,661 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    operating_income_2023 = 57890661
    return operating_income_2023
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________

## SF09 — Single-Fact

聯電114年度的其他綜合損益淨額是多少？

Gold record hash: `5a6367f45feaf28b8293f003750d65e4e37c8b890794f01cc98d9f523e97f2fa`

- Time：114年度
- Concept：其他綜合損益（淨額）
- Filter：None
- Logic：direct retrieval
- Gold answer：-4859711
- Unit：新臺幣仟元

| Fact ID | Concept | Year | Value | Unit | Period | Source |
|---|---|---:|---:|---|---|---|
| UMC_2025_other_comprehensive_income | 其他綜合損益（淨額） | 2025 | -4859711 | TWD_thousand | duration: 2025-01-01 ~ 2025-12-31 | 02_Financial_Facts!I58 |

### Gold Context

## 簡明綜合損益表
| 項目 | 114年 |
| :--- | ---: |
| 其他綜合損益（淨額） | -4,859,711 |

來源單位：新臺幣仟元

### Gold Python（此步驟未執行）

```python
def solution():
    # Grounding（來源：簡明財報）
    net_other_comprehensive_income_2025 = -4859711
    return net_other_comprehensive_income_2025
```

- [ ] 題意／語意標註正確
- [ ] 來源 facts／單位／期間正確
- [ ] Evidence 完整且必要
- [ ] Python 公式與答案正確

審查者：________；問題與處置：________
